// EDSP-MON CAHIER 2 — fonctionnement hors ligne
// - la page (index.html) : on essaie d'abord internet (donc toujours la dernière version), sinon la copie gardée sur l'appareil
// - la bibliothèque Supabase : gardée sur l'appareil pour pouvoir ouvrir l'application sans internet
// - les données (Supabase, API) ne passent jamais par ce fichier : l'application gère elle-même la synchronisation
const V = 'edsp2-v19';
const CDN = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js';

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(V);
    await Promise.all([
      c.add(new Request('./index.html', { cache: 'reload' })).catch(() => {}),
      fetch(CDN, { mode: 'no-cors' }).then(r => c.put(CDN, r)).catch(() => {})
    ]);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    const ks = await caches.keys();
    await Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);

  // bibliothèque Supabase : copie locale d'abord
  if (u.href === CDN) {
    e.respondWith(caches.match(CDN).then(m => m || fetch(r).then(x => {
      const y = x.clone();
      caches.open(V).then(c => c.put(CDN, y));
      return x;
    })));
    return;
  }

  // tout le reste hors de notre site (Supabase, API, polices…) : on ne touche à rien
  if (u.origin !== self.location.origin) return;
  if (u.pathname.endsWith('/sw.js')) return;

  // manifest et icônes de l'application : toujours la dernière version (pour que l'icône du téléphone se mette à jour)
  if (/\.webmanifest$|\/(icon-|apple-touch-icon)/.test(u.pathname)) {
    e.respondWith(fetch(r).catch(() => caches.match(r)));
    return;
  }

  const isPage = r.mode === 'navigate' || (r.headers.get('accept') || '').includes('text/html') ||
    u.pathname.endsWith('/') || u.pathname.endsWith('.html');

  if (isPage) {
    // internet d'abord (dernière version), copie locale si pas de connexion
    e.respondWith((async () => {
      try {
        // réseau très lent : au bout de 4 secondes on ouvre la copie gardée sur l'appareil (s'il y en a une)
        const cached = await (await caches.open(V)).match('./index.html');
        const ctl = new AbortController();
        const tm = cached ? setTimeout(() => ctl.abort(), 4000) : 0;
        const x = await fetch(u.href, { cache: 'no-store', credentials: 'same-origin', signal: ctl.signal });
        clearTimeout(tm);
        if (!x.ok) {
          // panne de l'hébergeur (erreur 5xx) : on ouvre la copie gardée sur l'appareil plutôt qu'une page d'erreur
          const c0 = await caches.open(V);
          const m0 = x.status >= 500 ? await c0.match('./index.html') : null;
          return m0 || x;
        }
        const b = await x.clone().blob();
        const c = await caches.open(V);
        await c.put('./index.html', new Response(b, { status: 200, headers: x.headers }));
        return x.redirected ? new Response(b, { status: 200, headers: x.headers }) : x;
      } catch (err) {
        const c = await caches.open(V);
        return (await c.match('./index.html')) || Response.error();
      }
    })());
    return;
  }

  // autres fichiers de notre site : copie locale tout de suite, mise à jour en arrière-plan
  e.respondWith(caches.match(r).then(m => {
    const n = fetch(r).then(x => {
      if (x.ok) { const y = x.clone(); caches.open(V).then(c => c.put(r, y)); }
      return x;
    }).catch(() => m);
    return m || n;
  }));
});
